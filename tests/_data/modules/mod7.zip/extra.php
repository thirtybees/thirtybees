<?php

die('extra php file');
